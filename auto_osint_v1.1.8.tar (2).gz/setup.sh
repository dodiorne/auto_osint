#!/bin/bash

## Check for not root

if [ "$EUID" -eq 0 ]
  then echo "This setup script should not be ran as root. It will ask when it needs it."
  exit
fi

### Make Directories ###

DIR="$(dirname $(readlink -f $0))"

cd "$DIR"

mkdir -p "./tools/"
mkdir -p "$HOME/.local/bin/"

sudo apt update && sudo apt install -y jq exiftool python3-pip

### Linkedin2Username

if ! command -v "linkedin2username" &> /dev/null; then
  git clone https://github.com/initstring/linkedin2username.git ./tools/linkedin2username
  python3 -m pip install -r ./tools/linkedin2username/requirements.txt

  ln -s "$(realpath ./tools/linkedin2username/linkedin2username.py)" "$HOME/.local/bin/linkedin2username"
  chmod +x "$HOME/.local/bin/linkedin2username"

else
  printf 'Skipping tool install step; "%s" already discovered\n' 'linkedin2username'
fi

### Gowitness

if ! command -v "gowitness" &> /dev/null; then
  curl -L -o "$HOME/.local/bin/gowitness" \
    "$(curl -s https://api.github.com/repos/sensepost/gowitness/releases/latest | jq -r '.assets[] | select(.browser_download_url | contains("linux")) | .browser_download_url')"

  chmod +x "$HOME/.local/bin/gowitness"

else
  printf 'Skipping tool install step; "%s" already discovered\n' 'gowitness'
fi

### PyMeta

if ! command -v "pymeta" &> /dev/null; then
  git clone https://github.com/m8r0wn/pymeta.git ./tools/pymeta
  python3 -m pip install -r ./tools/pymeta/requirements.txt

  bash -c "cd ./tools/pymeta/ && sudo python3 setup.py install"

else
  printf 'Skipping tool install step; "%s" already discovered\n' 'pymeta'
fi

### Sublist3r

if ! command -v "sublist3r" &> /dev/null; then
  git clone https://github.com/aboul3la/Sublist3r ./tools/sublist3r
  python3 -m pip install -r ./tools/sublist3r/requirements.txt

  ln -s "$(realpath ./tools/sublist3r/sublist3r.py)" "$HOME/.local/bin/sublist3r"
  chmod +x "$HOME/.local/bin/sublist3r"

else
  printf 'Skipping tool install step; "%s" already discovered\n' 'sublist3r'
fi

### o365Spray

if ! command -v "o365spray" &> /dev/null; then
  git clone https://github.com/0xZDH/o365spray ./tools/o365spray
  python3 -m pip install -r ./tools/o365spray/requirements.txt

  ln -s "$(realpath ./tools/o365spray/o365spray.py)" "$HOME/.local/bin/o365spray"
  chmod +x "$HOME/.local/bin/o365spray"

else
  printf 'Skipping tool install step; "%s" already discovered\n' 'o365spray'
fi

### TQ

if ! command -v "tq" &> /dev/null; then
  python3 -m pip install https://github.com/plainas/tq/zipball/stable

else
  printf 'Skipping tool install step; "%s" already discovered\n' 'tq'
fi

### Google Chrome Stable

if ! command -v "google-chrome" &> /dev/null; then
  curl -O https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
  sudo dpkg -i google-chrome-stable_current_amd64.deb
  rm google-chrome-stable_current_amd64.deb

else
  printf 'Skipping tool install step; "%s" already discovered\n' 'google-chrome'
fi

### Final Setup

ln -sf "$(realpath ./auto_osint.py)" "$HOME/.local/bin/auto_osint"
chmod +x "$HOME/.local/bin/auto_osint"

if [[ ":$PATH:" == *":$(realpath $HOME/.local/bin/):"* ]]; then
  printf '%s\n' 'Skipping $PATH step, already configured!' '' "Setup Finished! Now try 'auto_osint --help' for details"

else
  printf '\n# Line Added by "auto_osint" script\nexport PATH=%s:$PATH\n' "$(realpath $HOME/.local/bin/)" >> ~/.bashrc
  printf '\n# Line Added by "auto_osint" script\nexport PATH=%s:$PATH\n' "$(realpath $HOME/.local/bin/)" >> ~/.zshrc

  printf '%s\n' "" "Setup Finished! Please restart your shell to begin. Afterwards use 'auto_osint --help' for details"
fi
