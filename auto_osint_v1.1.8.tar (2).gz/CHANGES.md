# Changelog for Auto OSINT Tool

## Version 1.1.8

- Adds delay between page load and screenshot in Gowitness step

## Version 1.1.7

- Fixes gowitness step to use both subdomain lists

## Version 1.1.6

- Setup script now installs "google-chrome-stable" (used in gowitness step)
- Setup script refuses to run if ran with sudo

## Version 1.1.5

- Now saves output to ~/OSINT/CompanyName instead of ./OSINT
- Adds support to pull subdomains from crt.sh as well as Sublist3r
- Step dependencies are now checked before running commands (if skipped with --skip)
- Setup script now installs "tq" command (used for crt.sh step)
- Setup script now skips installing tools that are already installed, and does not append PATH text to .bashrc/.zshrc if it already exists in $PATH
- Fixes --version displaying format string

## Version 1.1.4

- Initial Release
